#!python

import pkg.fibo
from pkg.fact import factorial

print(pkg.fibo.fibonacci(20))
print(factorial(10))
