#include "stack.h"
#include "expression.h"

bool expression_check(const char *exp)
{
    bool status = (exp != NULL);

    if (status)
    {
        stack_clear();

        for (char *cptr = (char *)exp; status && (*cptr != '\0'); cptr++)
        {
            if (*cptr == '(')
            {
                status = stack_push(*cptr);
            }
            else if (*cptr == ')')
            {
                status = (0 != stack_pop());
            }
        }

        status = status && (0 == stack_pop());
    }

    return status;
}
