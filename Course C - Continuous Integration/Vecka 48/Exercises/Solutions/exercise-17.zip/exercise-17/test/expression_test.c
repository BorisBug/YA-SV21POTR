#include "unity.h"
#include "expression.h"

void setUp() {}
void tearDown() {}

void test_expression_check(void)
{
    TEST_ASSERT_FALSE(expression_check(NULL));
    TEST_ASSERT_FALSE(expression_check("1 + (2 * 3"));
    TEST_ASSERT_FALSE(expression_check("1 + )2 * 3"));
    TEST_ASSERT_FALSE(expression_check("1 + (2 * 3))"));
    TEST_ASSERT_TRUE(expression_check(""));
    TEST_ASSERT_TRUE(expression_check("1"));
    TEST_ASSERT_TRUE(expression_check("1 + (2 * 3)"));
    TEST_ASSERT_TRUE(expression_check("(1 + (2 * 3))"));
    TEST_ASSERT_TRUE(expression_check("1 + ()"));
}

int main(void)
{
    UNITY_BEGIN();
    RUN_TEST(test_expression_check);
    return UNITY_END();
}
