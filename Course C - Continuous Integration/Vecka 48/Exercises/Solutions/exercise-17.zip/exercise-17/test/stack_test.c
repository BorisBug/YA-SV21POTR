#include "stack.h"
#include "unity.h"

void setUp()
{
    stack_clear();
}
void tearDown() {}

void test_stack_clear(void)
{
    TEST_ASSERT_TRUE(stack_push('a'));
    TEST_ASSERT_TRUE(stack_push('b'));
    stack_clear();
    TEST_ASSERT_EQUAL_CHAR('\0', stack_pop());
}

void test_stack_push_pop(void)
{
    for (size_t i = 0; i < STACK_SIZE; i++)
    {
        TEST_ASSERT_TRUE(stack_push('('));
    }
    TEST_ASSERT_FALSE(stack_push('('));

    for (size_t i = 0; i < STACK_SIZE; i++)
    {
        TEST_ASSERT_EQUAL_CHAR('(', stack_pop());
    }
    TEST_ASSERT_EQUAL_CHAR('\0', stack_pop());
}

int main(void)
{
    UNITY_BEGIN();

    RUN_TEST(test_stack_clear);
    RUN_TEST(test_stack_push_pop);

    return UNITY_END();
}
