#!python

import module

module.function("Linda", 32)
