/**
 * @file stack.h
 * @author Faroch Mehri (faroch.mehri@ya.se)
 * @brief A stack implemented using a linked list.
 * @version 0.1
 * @date 2021-11-11
 *
 * @copyright Copyright (c) 2021
 *
 */
#ifndef STACK_H
#define STACK_H

#include <stddef.h>
#include <stdbool.h>

/**
 * @brief This function is used to clear the stack.
 *
 */
void stack_clear(void);

/**
 * @brief This function is used to push an integer to the stack.
 *
 * @param value The data to push
 * @return bool true if value is pushed successfully; otherwise false.
 */
bool stack_push(int value);

/**
 * @brief This function is used to check if the stack is empty or not.
 *
 * @return bool true if the stack is empty; otherwise false.
 */
bool stack_isempty(void);

/**
 * @brief This function is used to pop the top element from the stack.
 *
 * @return int The data popped from the stack.
 */
int stack_pop(void);

/**
 * @brief This function is used to get the number of elements on the stack.
 *
 * @return size_t The number of elements on the stack.
 */
size_t stack_available(void);

#endif
