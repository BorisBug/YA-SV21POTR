#include "unity.h"
#include "stack.h"

void setUp(void) {}

void tearDown(void) { stack_clear(); }

void test_stack_push(void)
{
    TEST_ASSERT_TRUE(stack_push(10));
    TEST_ASSERT_FALSE(stack_isempty());
    TEST_ASSERT_EQUAL_size_t(1, stack_available());

    TEST_ASSERT_TRUE(stack_push(20));
    TEST_ASSERT_FALSE(stack_isempty());
    TEST_ASSERT_EQUAL_size_t(2, stack_available());
}

void test_stack_pop(void)
{
    TEST_ASSERT_TRUE(stack_push(10));
    TEST_ASSERT_FALSE(stack_isempty());
    TEST_ASSERT_EQUAL_size_t(1, stack_available());

    TEST_ASSERT_TRUE(stack_push(20));
    TEST_ASSERT_FALSE(stack_isempty());
    TEST_ASSERT_EQUAL_size_t(2, stack_available());

    TEST_ASSERT_EQUAL_INT(20, stack_pop());
    TEST_ASSERT_EQUAL_size_t(1, stack_available());
    TEST_ASSERT_FALSE(stack_isempty());

    TEST_ASSERT_EQUAL_INT(10, stack_pop());
    TEST_ASSERT_EQUAL_size_t(0, stack_available());
    TEST_ASSERT_TRUE(stack_isempty());
}

void test_stack_clear(void)
{
    TEST_ASSERT_TRUE(stack_push(10));
    TEST_ASSERT_FALSE(stack_isempty());
    TEST_ASSERT_EQUAL_size_t(1, stack_available());

    TEST_ASSERT_TRUE(stack_push(20));
    TEST_ASSERT_FALSE(stack_isempty());
    TEST_ASSERT_EQUAL_size_t(2, stack_available());

    stack_clear();
    TEST_ASSERT_EQUAL_INT(0, stack_pop());
    TEST_ASSERT_EQUAL_size_t(0, stack_available());
    TEST_ASSERT_TRUE(stack_isempty());
}

int main(void)
{
    UNITY_BEGIN();

    RUN_TEST(test_stack_push);
    RUN_TEST(test_stack_pop);
    RUN_TEST(test_stack_clear);

    return UNITY_END();
}
