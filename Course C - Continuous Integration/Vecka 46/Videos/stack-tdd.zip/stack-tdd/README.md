# A stack implemented using a linked list

Use TDD to develop and test a single instance stack using a linked list

## Requirements

The stack module shall support the following operations

    1. Clearing the stack

    2. Pushing to the stack

    3. Checking if the stack is empty or not.

    4. Popping from the stack

    5. Getting the number of elements on the stack
