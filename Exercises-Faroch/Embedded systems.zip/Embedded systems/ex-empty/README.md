# Exercise xx - Embedded systems
