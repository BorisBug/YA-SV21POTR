#ifndef MODULE_H
#define MODULE_H

#include <stddef.h>
#include <string.h>

void get_string(char str[], size_t len);
void sort_string(char str[], size_t len);

#endif /* MODULE_H */
