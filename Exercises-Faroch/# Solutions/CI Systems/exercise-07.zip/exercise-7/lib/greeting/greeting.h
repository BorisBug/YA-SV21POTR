#ifndef GREETING_H
#define GREETING_H

#include <stdlib.h>

#define MAX_NAMES 8U
#define MAX_NAME_LENGTH 16U

char *greet(const char *str);

#endif
