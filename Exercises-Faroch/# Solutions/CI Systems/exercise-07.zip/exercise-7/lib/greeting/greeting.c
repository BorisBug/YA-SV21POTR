#include <ctype.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "greeting.h"

#define HELLOL "Hello, "
#define HELLOU "HELLO "
#define HELLO_MY_FRIEND "Hello, my friend."

static bool is_uppercase(const char *name);
static int8_t extract_names(const char *str);

static char names[MAX_NAMES][MAX_NAME_LENGTH + 1] = {0};
static char output[MAX_NAMES * (MAX_NAME_LENGTH + 3) + 10] = {0};

char *greet(const char *str)
{
    char *ptr = NULL;
    int8_t number_of_names = extract_names(str);

    if (number_of_names != -1)
    {
        if (number_of_names == 0)
        {
            ptr = HELLO_MY_FRIEND;
        }
        else
        {
            uint8_t uppers = 0, lowers = 0;
            memset(output, 0, sizeof(output));

            for (uint8_t i = 0; i < number_of_names; i++)
            {
                if (is_uppercase(names[i]))
                {
                    uppers++;
                }
                else
                {
                    lowers++;
                }
            }

            for (uint8_t i = 0, j = 0; (i < number_of_names) && (j < lowers); i++)
            {
                if (!is_uppercase(names[i]))
                {
                    if (j == 0)
                    {
                        sprintf(output, "%s%s", HELLOL, names[i]);
                    }
                    else if (j < lowers - 1)
                    {
                        strcat(output, ", ");
                        strcat(output, names[i]);
                    }
                    else
                    {
                        strcat(output, (lowers > 2) ? ", and " : " and ");
                        strcat(output, names[i]);
                    }

                    j++;

                    if (j == lowers)
                    {
                        strcat(output, ".");
                    }
                }
            }

            if ((lowers > 0) && (uppers > 0))
            {
                strcat(output, " AND ");
            }

            for (uint8_t i = 0, j = 0; (i < number_of_names) && (j < uppers); i++)
            {
                if (is_uppercase(names[i]))
                {
                    if (j == 0)
                    {
                        strcat(output, HELLOU);
                        strcat(output, names[i]);
                    }
                    else if (j < uppers - 1)
                    {
                        strcat(output, ", ");
                        strcat(output, names[i]);
                    }
                    else
                    {
                        strcat(output, (lowers > 2) ? ", AND " : " AND ");
                        strcat(output, names[i]);
                    }

                    j++;

                    if (j == uppers)
                    {
                        strcat(output, "!");
                    }
                }
            }

            ptr = output;
        }
    }

    return ptr;
}

static int8_t extract_names(const char *str)
{
    int8_t num = -1;

    memset(names, 0, sizeof(names));

    if (str != NULL)
    {
        num++;
        uint8_t i = 0;

        for (char *cptr = (char *)str; *cptr != '\0'; cptr++)
        {
            if (*cptr == ',')
            {
                i = 0;
                if (0 < strlen(names[num]))
                {
                    if (num == MAX_NAMES)
                    {
                        num = -1;
                        break;
                    }
                    num++;
                }
            }
            else
            {
                if (isalpha(*cptr))
                {
                    if (i == MAX_NAME_LENGTH)
                    {
                        num = -1;
                        break;
                    }

                    names[num][i] = *cptr;
                    i++;
                }
            }
        }

        if (num != -1)
        {
            if (0 < strlen(names[num]))
            {
                num++;
            }
        }
    }

    return num;
}

static bool is_uppercase(const char *name)
{
    bool result = true;

    for (char *cptr = (char *)name; *cptr != '\0'; cptr++)
    {
        if (islower(*cptr))
        {
            result = false;
            break;
        }
    }

    return result;
}
