#include "unity.h"
#include <string.h>
#include "greeting.h"

void setUp(void) {}
void tearDown(void) {}

void test_single_name(void)
{
    TEST_ASSERT_EQUAL_STRING("Hello, Bob.", greet("Bob"));

    char name[MAX_NAME_LENGTH + 2] = {0};
    for (uint8_t i = 0; i < sizeof(name) - 1; i++)
    {
        name[i] = 'A';
    }
    TEST_ASSERT_NULL(greet(name));
}

void test_no_name(void)
{
    TEST_ASSERT_NULL(greet(NULL));
    TEST_ASSERT_EQUAL_STRING("Hello, my friend.", greet(""));
}

void test_single_uppercase_name(void)
{
    TEST_ASSERT_EQUAL_STRING("HELLO JERRY!", greet("JERRY"));
    TEST_ASSERT_EQUAL_STRING("HELLO JERRY!", greet("JERR@Y"));
}

void test_double_names(void)
{
    TEST_ASSERT_EQUAL_STRING("Hello, Jill and Jane.", greet("Jill, Jane"));
}

void test_multiple_names(void)
{
    TEST_ASSERT_EQUAL_STRING("Hello, Amy, Brian, and Charlotte.", greet("Amy, Brian, Charlotte"));

    char names[(MAX_NAMES + 1) * (MAX_NAME_LENGTH + 1)] = {0};
    for (uint8_t i = 0; i <= MAX_NAMES; i++)
    {
        strcat(names, "Bob, ");
    }
    TEST_ASSERT_NULL(greet(names));
}

void test_mixed_names(void)
{
    TEST_ASSERT_EQUAL_STRING("Hello, Amy and Charlotte. AND HELLO BRIAN!", greet("Amy, BRIAN, Charlotte"));
}

int main(void)
{
    UNITY_BEGIN();

    RUN_TEST(test_single_name);
    RUN_TEST(test_no_name);
    RUN_TEST(test_single_uppercase_name);
    RUN_TEST(test_double_names);
    RUN_TEST(test_multiple_names);
    RUN_TEST(test_mixed_names);

    return UNITY_END();
}
