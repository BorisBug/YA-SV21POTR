#include "list.h"
#include <stdlib.h>

bool list_insert(int data)
{
}

size_t list_available(void)
{
}

size_t list_find(int data)
{
}

bool list_get_data(size_t n, int *ptr)
{
}

bool list_delete(int data)
{
}

bool list_edit(int old_data, int new_data)
{
}

void list_clear(void)
{
}
