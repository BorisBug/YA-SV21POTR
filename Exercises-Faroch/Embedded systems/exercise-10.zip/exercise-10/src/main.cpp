/**
 * @file main.cpp
 * @author Faroch Mehri (faroch.mehri@ya.se)
 * @brief Exercise 10. Look at circuit.jpg.
 *        Control brightness of the LED using the potentiometer.
 *        The LED circuit is connected to an output PWM pin and the potentiometer is connected to an input analog pin.
 *        To learn how a potentiometer works, look at https://arduinogetstarted.com/tutorials/arduino-potentiometer
 * @version 0.1
 * @date 2022-01-07
 *
 * @copyright Copyright (c) 2022
 *
 */
#include <Arduino.h>

void setup()
{
}

void loop()
{
}
