#include <Arduino.h>

#define BUTTON_PIN 33

void setup()
{
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    Serial.begin(9600);
    delay(2000);
}

void loop_proof_of_bouncing()
{
    static uint8_t counter = 0;
    static uint8_t prev = HIGH;
    uint8_t cur_state = digitalRead(BUTTON_PIN);

    // proof of bouncing
    if(cur_state != prev)
    {
        counter++;
        prev = cur_state;

        if(cur_state==HIGH)
            Serial.printf("%d HIGH\n", counter);
        else
            Serial.printf("%d LOW\n", counter);
    }
}


void loop()
{
    loop_proof_of_bouncing();
}
