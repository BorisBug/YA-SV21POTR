#compile 
gcc debounce.c -DRUN_ON_PC -o debounce 

#run
./debounce