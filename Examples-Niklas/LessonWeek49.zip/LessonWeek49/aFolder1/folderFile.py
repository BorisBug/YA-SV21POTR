def Subtract(number1, number2):
    number3 = number1 - number2
    print(number1, "minus", number2, "equals", number3)
    return number3


def Subtract_Again(number1, number2):
    number3 = number1 - number2
    print(number1, "minus", number2, "equals", number3)
    return number3
