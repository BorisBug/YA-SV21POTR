def Divide(number1, number2):
    number3 = number1 / number2
    print(number1, "divided by", number2, "equals", number3)
    return number3


def Divide_Again(number1, number2):
    number3 = number1 / number2
    print(number1, "divided by", number2, "equals", number3)
    return number3
