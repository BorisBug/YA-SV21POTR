def Add(number1, number2):
    number3 = number1 + number2
    print(number1, "plus", number2, "equals", number3)
    return number3


def Multiply(number1, number2):
    number3 = number1 * number2
    print(number1, "times", number2, "equals", number3)
    return number3
