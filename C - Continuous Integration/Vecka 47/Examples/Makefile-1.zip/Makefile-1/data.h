#ifndef DATA_H
#define DATA_H

int get_data(void);

#endif
