#include "data.h"

static int data = 10;

int get_data(void)
{
    return data;
}
