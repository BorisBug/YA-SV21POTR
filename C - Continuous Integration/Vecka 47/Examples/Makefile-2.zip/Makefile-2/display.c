#include <stdio.h>
#include "display.h"

void display(int data)
{
    printf("Data is %d\n", data);
}
