# Roman Numeral to Decimal

Using TDD develop a function to convert Roman numerals to decimal numbers.

To compile the module, unity and build and run the test, use make and a makefile.

In Github action make a workflow (C/C++ with Make) for your project.

Use the centeralized workflow strategy.
