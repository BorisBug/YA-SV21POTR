#ifndef ROMAN_H
#define ROMAN_H

int roman2decimal(const char *rnum);

#endif /* ROMAN_H */
