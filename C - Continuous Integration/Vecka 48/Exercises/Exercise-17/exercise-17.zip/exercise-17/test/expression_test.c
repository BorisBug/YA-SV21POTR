#include "unity.h"
#include "expression.h"

void setUp() {}
void tearDown() {}

int main(void)
{
    UNITY_BEGIN();

    return UNITY_END();
}
