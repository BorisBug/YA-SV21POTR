#ifndef EXPRESSION_H
#define EXPRESSION_H

#include <stdlib.h>
#include <stdbool.h>

bool expression_check(const char *exp);

#endif /* EXPRESSION_H */
