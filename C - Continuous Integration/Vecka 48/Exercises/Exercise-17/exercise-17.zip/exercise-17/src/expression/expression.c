#include "stack.h"
#include "expression.h"

bool expression_check(const char *exp)
{
    bool status = false;

    return status;
}
