# Fizz Buzz Whiz

Using TDD, develop a function that for a given natural number greater zero returns:

    “Fizz” if the number is divisible by 3

    “Buzz” if the number is divisible by 5

    “FizzBuzz” if the number is divisible by both 3 and 5

    “Whiz” if the number is a prime

    The number if it is not divisible by both 3 and 5

To compile the module, unity and build and run the test, use make and a makefile.

In Github action make a workflow action (C/C++ with Make) for the project.
