# Exercise 4 - GitFlow Strategy

Answer each question here under the question.

## What is a programming language?

## What is a compiler?

## What is a debugger?

## What is an IDE (Integrated Development Environment)?

## What does it mean to be a programmer?

## Is C a high level programming language? Why?

## What is voltage? What is the unit of voltage?

## What is current? What is the unit of current?

## What is resistance? What is the unit of resistance?

## What is the most manufactured device in history?

## What is an integer number?

## What is a real number?

## What is a prime number?

## What is RAM(Random Access Memory)?

## What is ROM(Read-Only Memory)?
