# I2C

## Connections

Teensy(Slave) ........... ESP32(Master)

Vin ...................... USB

SDA(18) .................. SDA(23)

SCL(19) .................. SCL(22)

GND ...................... GND
