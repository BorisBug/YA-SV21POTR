# Bluetooth - UART over BLE

In this program the builtin LED of ESP32 can be controlled via Bluetooth
Install nRF Toolbox on your mobile and connect to ESP32 and send 1 to turn the LED on and 0 to turn the LED off
