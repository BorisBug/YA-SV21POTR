// Inclusion gard
#ifndef MODULE_H
#define MODULE_H

void print(int x, int y, char operation, int z); // Declaration of print.

#endif /* MODULE_H */
