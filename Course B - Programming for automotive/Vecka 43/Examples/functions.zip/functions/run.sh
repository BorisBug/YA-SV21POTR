
gcc main.c ./module/module.c -I./module -o main && ./main.exe test
