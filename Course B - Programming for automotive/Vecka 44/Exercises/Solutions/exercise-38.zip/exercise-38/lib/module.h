#ifndef MODULE_H
#define MODULE_H

#include <stddef.h>
#include <string.h>

void get_string(char str[], size_t len);
void sort_string(size_t len, char str[len]);

#endif /* MODULE_H */
