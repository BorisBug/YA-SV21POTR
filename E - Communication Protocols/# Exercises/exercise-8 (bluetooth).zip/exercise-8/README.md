# Bluetooth - UART over BLE

Make a program to ESP32 as a BLE Server to receive a string from a client

and convert it to uppercase and return it to the client.

Use nRF Toolbox or Bluetooth for Arduino on your phone as the client.
